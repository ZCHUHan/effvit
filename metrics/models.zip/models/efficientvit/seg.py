from typing import List, Optional

import torch
import torch.nn as nn

from models.utils import build_kwargs_from_config
from models.nn import OpSequential, ConvLayer, DAGBlock, UpSampleLayer, MBConv, ResidualBlock, IdentityLayer
from models.efficientvit.backbone import EfficientViTBackbone
__all__ = [
    "EfficientViTSeg",
    "efficientvit_seg_b0",
    "efficientvit_seg_b1",
    "efficientvit_seg_b2",
    "efficientvit_seg_b3",
    "branch_efficientvit_seg_b0"
]


class SegHead(DAGBlock):
    def __init__(self, fid_list: List[str], in_channel_list: List[int], stride_list: List[int], head_stride: int, head_width: int, head_depth: int, expand_ratio: float, final_expand: Optional[float], n_classes: int, dropout_rate=0, norm="bn2d", act_func="hswish"):
        inputs = {}
        self.n_classes = n_classes
        for fid, in_channel, stride in zip(fid_list, in_channel_list, stride_list):
            factor = stride // head_stride
            if factor == 1:
                inputs[fid] = ConvLayer(in_channel, head_width, 1, norm=norm, act_func=None)
            else:
                inputs[fid] = OpSequential([
                    ConvLayer(in_channel, head_width, 1, norm=norm, act_func=None),
                    UpSampleLayer(factor=factor),
                    # UpSampleLayer(size=size),
                ])
        
        middle = []
        for _ in range(head_depth):
            block = MBConv(
                head_width,                 # 32
                head_width,                 # 32
                expand_ratio=expand_ratio,  # 4
                norm=norm, 
                act_func=(act_func, act_func, None),
            )
            middle.append(ResidualBlock(block, IdentityLayer()))
        middle = OpSequential(middle)

        outputs = {
            "segout": OpSequential([
                None if final_expand is None else ConvLayer(head_width, head_width * final_expand, 1, norm=norm, act_func=act_func),
                ConvLayer(
                    head_width * (final_expand or 1), 
                    n_classes, 
                    1, 
                    use_bias=True, 
                    dropout_rate=dropout_rate, 
                    norm=None, 
                    act_func=None
                )
            ])
        }
        
        super(SegHead, self).__init__(inputs, "add", None, middle=middle, outputs=outputs)


class EfficientViTSeg(nn.Module):
    def __init__(self, backbone: EfficientViTBackbone, head: SegHead) -> None:
        super().__init__()
        self.backbone = backbone
        self.head = head
    
    def forward(self, x: torch.Tensor, fix_bn=True) -> torch.Tensor:
        # print(x.shape)
        feed_dict = self.backbone(x, fix_bn)
        # print("stage4", feed_dict["stage4"].shape)
        # print("stage3", feed_dict["stage3"].shape)
        # print("stage2", feed_dict["stage2"].shape)
        # feed_conv = feed_dict["stage2"]
        feed_dict = self.head(feed_dict)
        # print("segout", feed_dict["segout"].shape)
        # return feed_dict["segout"], feed_dict["stage4"], None #, feed_conv
        # return feed_dict["segout"], None, None #, feed_conv
        return feed_dict["segout"]

def efficientvit_seg_b0(dataset: str, **kwargs) -> EfficientViTSeg:
    from models.efficientvit.backbone import efficientvit_backbone_b0
    backbone = efficientvit_backbone_b0(**kwargs)

    if dataset == "cityscapes":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[128, 64, 32],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=32,
            head_depth=1,
            expand_ratio=4,
            final_expand=4,
            n_classes=19,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    else:
        raise NotImplementedError
    model = EfficientViTSeg(backbone, head)
    return model

def branch_efficientvit_seg_b0(dataset: str, **kwargs) -> EfficientViTSeg:
    from models.efficientvit.backbone import branch_efficientvit_backbone_b0
    backbone = branch_efficientvit_backbone_b0(**kwargs)

    if dataset == "cityscapes":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[128, 64, 32],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=32,
            head_depth=1,
            expand_ratio=4,
            final_expand=4,
            n_classes=19,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    else:
        raise NotImplementedError
    model = EfficientViTSeg(backbone, head)
    return model



def efficientvit_seg_b1(dataset: str, **kwargs) -> EfficientViTSeg:
    from models.efficientvit.backbone import efficientvit_backbone_b1
    backbone = efficientvit_backbone_b1(**kwargs)

    if dataset == "cityscapes":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[256, 128, 64],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=64,
            head_depth=3,
            expand_ratio=4,
            final_expand=4,
            n_classes=19,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    elif dataset == "ade20k":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[256, 128, 64],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=64,
            head_depth=3,
            expand_ratio=4,
            final_expand=None,
            n_classes=150,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    else:
        raise NotImplementedError
    model = EfficientViTSeg(backbone, head)
    return model




def efficientvit_seg_b2(dataset: str, **kwargs) -> EfficientViTSeg:
    from models.efficientvit.backbone import efficientvit_backbone_b2
    backbone = efficientvit_backbone_b2(**kwargs)

    if dataset == "cityscapes":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[384, 192, 96],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=96,
            head_depth=3,
            expand_ratio=4,
            final_expand=4,
            n_classes=19,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    elif dataset == "ade20k":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[384, 192, 96],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=96,
            head_depth=3,
            expand_ratio=4,
            final_expand=None,
            n_classes=150,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    else:
        raise NotImplementedError
    model = EfficientViTSeg(backbone, head)
    return model


def efficientvit_seg_b3(dataset: str, **kwargs) -> EfficientViTSeg:
    from models.efficientvit.backbone import efficientvit_backbone_b3
    backbone = efficientvit_backbone_b3(**kwargs)

    if dataset == "cityscapes":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[512, 256, 128],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=128,
            head_depth=3,
            expand_ratio=4,
            final_expand=4,
            n_classes=19,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    elif dataset == "ade20k":
        head = SegHead(
            fid_list=["stage4", "stage3", "stage2"],
            in_channel_list=[512, 256, 128],
            stride_list=[32, 16, 8],
            head_stride=8,
            head_width=128,
            head_depth=3,
            expand_ratio=4,
            final_expand=None,
            n_classes=150,
            **build_kwargs_from_config(kwargs, SegHead),
        )
    else:
        raise NotImplementedError
    model = EfficientViTSeg(backbone, head)
    return model

