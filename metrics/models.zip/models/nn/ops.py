from typing import Dict, List, Tuple, Union, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.utils import get_same_padding, resize, val2list, val2tuple, merge_tensor
from models.nn.norm import build_norm
from models.nn.act import build_act
from models.nn.resize_new_pytorch import resize_new

__all__ = [
    "ConvLayer",
    "UpSampleLayer",
    "LinearLayer",
    "IdentityLayer",
    "DSConv",
    "MBConv",
    "LiteMSA",
    "EfficientViTBlock",
    "ResidualBlock",
    "DAGBlock",
    "OpSequential",
]


#################################################################################
#                             Basic Layers                                      #
#################################################################################


class ConvLayer(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size=3,
        stride=1,
        dilation=1,
        groups=1,
        use_bias=False,
        dropout_rate=0,
        norm="bn2d",
        act_func="relu",
    ):
        super(ConvLayer, self).__init__()

        padding = get_same_padding(kernel_size)
        padding *= dilation

        self.dropout = nn.Dropout2d(dropout_rate, inplace=False) if dropout_rate > 0 else None
        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(kernel_size, kernel_size),
            stride=(stride, stride),
            padding=padding,
            dilation=(dilation, dilation),
            groups=groups,
            bias=use_bias,
        )
        self.norm = build_norm(norm, num_features=out_channels)
        self.act = build_act(act_func)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.dropout is not None:
            x = self.dropout(x)
        x = self.conv(x)
        if self.norm:
            x = self.norm(x)
        if self.act:
            x = self.act(x)
        return x


class UpSampleLayer(nn.Module):
    def __init__(
        self,
        mode="bicubic",
        size: Union[int, Tuple[int, int], List[int], None] = None,
        factor=2,
        align_corners=False,
    ):
        super(UpSampleLayer, self).__init__()
        self.mode = mode
        self.size = val2list(size, 2) if size is not None else None
        self.factor = None if self.size is not None else factor
        self.align_corners = align_corners

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return resize(x, self.size, self.factor, self.mode, self.align_corners)
        # print(self.factor)
        # print(x.shape)
        # return resize_new(x, scale_factor=[1,1,self.factor,self.factor], mode=self.mode, align_corners=self.align_corners)


class LinearLayer(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        use_bias=True,
        dropout_rate=0,
        norm=None,
        act_func=None,
    ):
        super(LinearLayer, self).__init__()

        self.dropout = nn.Dropout(dropout_rate, inplace=False) if dropout_rate > 0 else None
        self.linear = nn.Linear(in_features, out_features, use_bias)
        self.norm = build_norm(norm, num_features=out_features)
        self.act = build_act(act_func)
    
    def _try_squeeze(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() > 2:
            x = torch.flatten(x, start_dim=1)
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._try_squeeze(x)
        if self.dropout:
            x = self.dropout(x)
        x = self.linear(x)
        if self.norm:
            x = self.norm(x)
        if self.act:
            x = self.act(x)
        return x


class IdentityLayer(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x


#################################################################################
#                             Basic Blocks                                      #
#################################################################################


class DSConv(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size=3,
        stride=1,
        use_bias=False,
        norm=("bn2d", "bn2d"),
        act_func=("relu6", None),
    ):
        super(DSConv, self).__init__()

        use_bias = val2tuple(use_bias, 2)
        norm = val2tuple(norm, 2)
        act_func = val2tuple(act_func, 2)

        self.depth_conv = ConvLayer(
            in_channels,
            in_channels,
            kernel_size,
            stride,
            groups=in_channels,
            norm=norm[0],
            act_func=act_func[0],
            use_bias=use_bias[0],
        )
        self.point_conv = ConvLayer(
            in_channels,
            out_channels,
            1,
            norm=norm[1],
            act_func=act_func[1],
            use_bias=use_bias[1],
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.depth_conv(x)
        x = self.point_conv(x)
        return x


class MBConv(nn.Module):
    def __init__(
        self,
        in_channels: int, # 32
        out_channels: int, # 32 
        kernel_size=3,
        stride=1,
        mid_channels=None,
        expand_ratio=6, # 4
        use_bias=False,
        norm=("bn2d", "bn2d", "bn2d"),
        act_func=("relu6", "relu6", None),
    ):
        super(MBConv, self).__init__()

        use_bias = val2tuple(use_bias, 3)
        norm = val2tuple(norm, 3)
        act_func = val2tuple(act_func, 3)
        mid_channels = mid_channels or round(in_channels * expand_ratio)

        self.inverted_conv = ConvLayer(
            in_channels,
            mid_channels,
            1,
            stride=1,
            norm=norm[0],
            act_func=act_func[0],
            use_bias=use_bias[0],
        )
        self.depth_conv = ConvLayer(
            mid_channels,
            mid_channels,
            kernel_size,
            stride=stride,
            groups=mid_channels,
            norm=norm[1],
            act_func=act_func[1],
            use_bias=use_bias[1],
        )
        self.point_conv = ConvLayer(
            mid_channels,
            out_channels,
            1,
            norm=norm[2],
            act_func=act_func[2],
            use_bias=use_bias[2],
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.inverted_conv(x)
        x = self.depth_conv(x)
        x = self.point_conv(x)
        return x

# class LiteMSA(nn.Module):
#     r""" Lightweight multi-scale attention """
#     def __init__(
#         self,
#         in_channels: int,
#         out_channels: int,
#         heads: Optional[int] = None,
#         heads_ratio: float = 1.0,
#         dim=8,
#         use_bias=False,
#         norm=(None, "bn2d"),
#         act_func=(None, None),
#         kernel_func="relu",
#         scales: Tuple[int, ...] = (5,),
#     ):
#         super(LiteMSA, self).__init__()
#         heads = heads or int(in_channels // dim * heads_ratio)

#         total_dim = heads * dim

#         use_bias = val2tuple(use_bias, 2)
#         norm = val2tuple(norm, 2)
#         act_func = val2tuple(act_func, 2)

#         self.dim = dim
#         self.qkv_layers = nn.ModuleDict({
#             name: 
#                 ConvLayer(
#                     in_channels,
#                     total_dim,
#                     kernel_size=1,
#                     norm=norm[0],
#                     use_bias=use_bias[0],
#                     act_func=act_func[0],
#                 )
#             for name in ["q", "k", "v"]
#         })
#         self.aggreg = nn.ModuleDict({
#             name: nn.ModuleList(
#                 [
#                     nn.Sequential(
#                         nn.Conv2d(
#                             total_dim,
#                             total_dim,
#                             scale, 
#                             padding=get_same_padding(scale), 
#                             groups=total_dim,
#                             bias=use_bias[0],
#                         ),
#                         nn.Conv2d(
#                             total_dim,
#                             total_dim,
#                             1, 
#                             groups=heads,
#                             bias=use_bias[0], 
#                         )
#                     )
#                     for scale in scales
#                 ]
#             )
#             for name in ["q", "k", "v"]
#         })
#         self.kernel_func = build_act(kernel_func, inplace=False)

#         self.proj = ConvLayer(
#             total_dim * (1 + len(scales)),
#             out_channels,
#             1,
#             use_bias=use_bias[1],
#             norm=norm[1],
#             act_func=act_func[1],
#         )
    
#     def forward(self, x: torch.Tensor) -> torch.Tensor:
#         B, _, H, W = list(x.size())

#         q = self.qkv_layers["q"](x)
#         k = self.qkv_layers["k"](x)
#         v = self.qkv_layers["v"](x)
#         # qkv = self.qkv(x)
#         qkv_dict = {
#             "q":   q,
#             "k":   k,
#             "v":   v
#         }
#         concat_qkv = {}
#         for name in ["q", "k", "v"]:
#             # obtain scale-1 qkv
#             x = qkv_dict[name]
#             # scale-2 qkv
#             x1 = self.aggreg[name][0][0](x)
#             x2 = self.aggreg[name][0][1](x1)
#             # concat scale-1&2 qkv
#             concat_x = torch.cat((x, x2), dim=1)
#             concat_qkv[name] = concat_x
#             # reshape to B, heads, H*W, dim(16)
#             concat_qkv[name] = concat_qkv[name].reshape(B, -1, self.dim, H*W).contiguous().transpose(-1,-2).contiguous()
#             # only relu on q and k
#             concat_qkv[name] = self.kernel_func(concat_qkv[name]) if name != "v" else concat_qkv[name] 
#         # headwise attention
#         _, total_heads, _, _ = concat_qkv["q"].shape
#         out = torch.zeros_like(concat_qkv["q"])
#         for i in range(total_heads):
#             q = concat_qkv["q"][:, i, :, :]
#             k = concat_qkv["k"][:, i, :, :]
#             v = concat_qkv["v"][:, i, :, :]
#             kv = torch.matmul(k.transpose(-1, -2), v)
#             scale = torch.matmul(q, torch.sum(k.transpose(-1, -2), dim=-1, keepdim=True))
#             out[:, i, :, :] = torch.matmul(q, kv) / (scale + 1e-15)
#         # final projecttion
#         out = torch.transpose(out, -1, -2)
#         # print("out", out.shape)
#         out = torch.reshape(out, (B, -1, H, W))
#         out = self.proj(out)

#         return out


class LiteMSA(nn.Module):
    r""" Lightweight multi-scale attention """
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        heads: Optional[int] = None,
        heads_ratio: float = 1.0,
        dim=8,
        use_bias=False,
        norm=(None, "bn2d"),
        act_func=(None, None),
        kernel_func="relu",
        scales: Tuple[int, ...] = (5,),
    ):
        super(LiteMSA, self).__init__()
        heads = heads or int(in_channels // dim * heads_ratio)

        total_dim = heads * dim

        use_bias = val2tuple(use_bias, 2)
        norm = val2tuple(norm, 2)
        act_func = val2tuple(act_func, 2)

        self.dim = dim
        self.qkv_layers = nn.ModuleDict({
            name: 
                ConvLayer(
                    in_channels,
                    total_dim,
                    kernel_size=1,
                    norm=norm[0],
                    use_bias=use_bias[0],
                    act_func=act_func[0],
                )
            for name in ["q", "k", "v"]
        })
        self.aggreg = nn.ModuleDict({
            name: nn.ModuleList(
                [
                    nn.Sequential(
                        nn.Conv2d(
                            total_dim,
                            total_dim,
                            scale, 
                            padding=get_same_padding(scale), 
                            groups=total_dim,
                            bias=use_bias[0],
                        ),
                        nn.Conv2d(
                            total_dim,
                            total_dim,
                            1, 
                            groups=heads,
                            bias=use_bias[0], 
                        )
                    )
                    for scale in scales
                ]
            )
            for name in ["q", "k", "v"]
        })
        self.kernel_func = build_act(kernel_func, inplace=False)

        self.proj = ConvLayer(
            total_dim * (1 + len(scales)),
            out_channels,
            1,
            use_bias=use_bias[1],
            norm=norm[1],
            act_func=act_func[1],
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, _, H, W = list(x.size())

        q = self.qkv_layers["q"](x)
        k = self.qkv_layers["k"](x)
        v = self.qkv_layers["v"](x)
        # qkv = self.qkv(x)
        qkv_dict = {
            "q":   q,
            "k":   k,
            "v":   v
        }
        concat_qkv = {}
        for name in ["q", "k", "v"]:
            # obtain scale-1 qkv
            x = qkv_dict[name]
            # scale-2 qkv
            x1 = self.aggreg[name][0][0](x)
            x2 = self.aggreg[name][0][1](x1)
            # concat scale-1&2 qkv
            concat_x = torch.cat((x, x2), dim=1)
            concat_qkv[name] = concat_x
            # reshape to B, heads, H*W, dim(16)
            concat_qkv[name] = concat_qkv[name].reshape(B, -1, self.dim, H*W).contiguous().transpose(-1,-2).contiguous()
            # only relu on q and k
            concat_qkv[name] = self.kernel_func(concat_qkv[name]) if name != "v" else concat_qkv[name] 

        q = concat_qkv["q"]
        kv = torch.matmul(concat_qkv["k"].transpose(-1, -2), concat_qkv["v"])
        # kv = torch.matmul(concat_qkv["k"].transpose(-1, -2), v)
        scale = torch.matmul(q, torch.sum(concat_qkv["k"].transpose(-1, -2), dim=-1, keepdim=True)) 
        out = torch.matmul(q, kv)
        out = out / (scale + 1e-15)
        # out = out[..., :-1] / (out[..., -1:] + 1e-15)

        # final projecttion
        out = torch.transpose(out, -1, -2)
        # print("out", out.shape)
        out = torch.reshape(out, (B, -1, H, W))
        out = self.proj(out)

        return out



# class LiteMSA(nn.Module):
#     r""" Lightweight multi-scale attention """
#     def __init__(
#         self,
#         in_channels: int,
#         out_channels: int,
#         heads: Optional[int] = None,
#         heads_ratio: float = 1.0,
#         dim=8,
#         use_bias=False,
#         norm=(None, "bn2d"),
#         act_func=(None, None),
#         kernel_func="relu",
#         scales: Tuple[int, ...] = (5,),
#     ):
#         super(LiteMSA, self).__init__()
#         heads = heads or int(in_channels // dim * heads_ratio)

#         total_dim = heads * dim

#         use_bias = val2tuple(use_bias, 2)
#         norm = val2tuple(norm, 2)
#         act_func = val2tuple(act_func, 2)

#         self.dim = dim
#         self.qkv = ConvLayer(
#             in_channels,
#             3 * total_dim,
#             1,
#             use_bias=use_bias[0],
#             norm=norm[0],
#             act_func=act_func[0],
#         )
#         self.aggreg = nn.ModuleList(
#             [
#                 nn.Sequential(
#                     nn.Conv2d(
#                         3 * total_dim, 3 * total_dim, scale, padding=get_same_padding(scale), groups=3 * total_dim, bias=use_bias[0],
#                     ),
#                     nn.Conv2d(3 * total_dim, 3 * total_dim, 1, groups=3 * heads, bias=use_bias[0]),
#                 )
#                 for scale in scales
#             ]
#         )
#         self.kernel_func = build_act(kernel_func, inplace=False)

#         self.proj = ConvLayer(
#             total_dim * (1 + len(scales)),
#             out_channels,
#             1,
#             use_bias=use_bias[1],
#             norm=norm[1],
#             act_func=act_func[1],
#         )
    
#     def forward(self, x: torch.Tensor) -> torch.Tensor:
#         B, _, H, W = list(x.size())
#         # print("B, _, H, W", B, _, H, W)
#         # print("dim",self.dim)
#         # generate multi-scale q, k, v
#         # print("x", x.shape)
#         qkv = self.qkv(x)
#         # print("qkv", qkv.shape)
#         multi_scale_qkv = [qkv]
#         for op in self.aggreg:
#             multi_scale_qkv.append(op(qkv))
#         multi_scale_qkv = torch.cat(multi_scale_qkv, dim=1)
#         # print("multi_scale_qkv", multi_scale_qkv.shape)
#         multi_scale_qkv = torch.reshape(
#             multi_scale_qkv,
#             (
#                 B,
#                 -1,
#                 3 * self.dim,
#                 H * W,
#             ),
#         )
#         # print("multi_scale_qkv", multi_scale_qkv.shape)
#         multi_scale_qkv = torch.transpose(multi_scale_qkv, -1, -2)
#         # print("multi_scale_qkv", multi_scale_qkv.shape)
#         q, k, v = (
#             multi_scale_qkv[..., 0 : self.dim],
#             multi_scale_qkv[..., self.dim : 2 * self.dim],
#             multi_scale_qkv[..., 2 * self.dim :],
#         )
#         # print("q", q.shape)
#         # print("k", k.shape)
#         # print("v", v.shape)
        
#         # lightweight global attention
#         q = self.kernel_func(q)
#         k = self.kernel_func(k)
#         # print("q", q.shape)
#         # print("k", k.shape)
#         trans_k = k.transpose(-1, -2) # shape: (B, H, C, H*W)
#         v = F.pad(v, (0, 1), mode="constant", value=1)
#         kv = torch.matmul(trans_k, v)
#         out = torch.matmul(q, kv)
#         out = out[..., :-1] / (out[..., -1:] + 1e-15)
#         # final projecttion
#         out = torch.transpose(out, -1, -2)
#         # print("out", out.shape)
#         out = torch.reshape(out, (B, -1, H, W))
#         out = self.proj(out)

#         return out


class EfficientViTBlock(nn.Module):
    def __init__(self, in_channels: int, heads_ratio: float = 1.0, dim=32, expand_ratio: float = 4, norm="bn2d", act_func="hswish"):
        super(EfficientViTBlock, self).__init__()
        self.context_module = ResidualBlock(
            LiteMSA(
                in_channels=in_channels,
                out_channels=in_channels,
                heads_ratio=heads_ratio,
                dim=dim,
                norm=(None, norm),
            ),
            IdentityLayer(),
        )
        local_module = MBConv(
            in_channels=in_channels,
            out_channels=in_channels,
            expand_ratio=expand_ratio,
            use_bias=(True, True, False),
            norm=(None, None, norm),
            act_func=(act_func, act_func, None),
        )
        self.local_module = ResidualBlock(local_module, IdentityLayer())
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.context_module(x)
        x = self.local_module(x)
        return x


#################################################################################
#                             Functional Blocks                                 #
#################################################################################


class ResidualBlock(nn.Module):
    def __init__(
        self,
        main: Optional[nn.Module],
        shortcut: Optional[nn.Module],
        post_act=None,
        pre_norm: Optional[nn.Module] = None,
    ):
        super(ResidualBlock, self).__init__()

        self.pre_norm = pre_norm
        self.main = main
        self.shortcut = shortcut
        self.post_act = build_act(post_act)

    def forward_main(self, x: torch.Tensor) -> torch.Tensor:
        if self.pre_norm is None:
            return self.main(x)
        else:
            return self.main(self.pre_norm(x))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.main is None:
            res = x
        elif self.shortcut is None:
            res = self.forward_main(x)
        else:
            res = self.forward_main(x) + self.shortcut(x)
            if self.post_act:
                res = self.post_act(res)
        return res


class DAGBlock(nn.Module):
    def __init__(
        self,
        inputs: Dict[str, nn.Module],
        merge_mode: str,
        post_input: Optional[nn.Module],
        middle: nn.Module,
        outputs: Dict[str, nn.Module],
    ):
        super(DAGBlock, self).__init__()

        self.input_keys = list(inputs.keys())
        self.input_ops = nn.ModuleList(list(inputs.values()))
        self.merge_mode = merge_mode
        self.post_input = post_input

        self.middle = middle

        self.output_keys = list(outputs.keys())
        self.output_ops = nn.ModuleList(list(outputs.values()))

    def forward(self, feature_dict: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        feat = [op(feature_dict[key]) for key, op in zip(self.input_keys, self.input_ops)]
        feat = merge_tensor(feat, self.merge_mode, dim=1)
        if self.post_input is not None:
            feat = self.post_input(feat)
        feat = self.middle(feat)
        for key, op in zip(self.output_keys, self.output_ops):
            feature_dict[key] = op(feat)
        return feature_dict


class OpSequential(nn.Module):
    def __init__(self, op_list: List[Optional[nn.Module]]):
        super(OpSequential, self).__init__()
        valid_op_list = []
        for op in op_list:
            if op is not None:
                valid_op_list.append(op)
        self.op_list = nn.ModuleList(valid_op_list)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for op in self.op_list:
            x = op(x)
        return x
