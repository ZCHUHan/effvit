from typing import Dict, Optional, Type
import torch
import numpy as np
import decimal
from decimal import Decimal
import torch.nn as nn
from models.utils import build_kwargs_from_config
from models.nn.lsq import LsqQuantizer4input
from models.nn.quant_lsq import  PACT
from models.nn.hardpwl import hardpwl
# torch.ops.load_library("hardpwl/build/lib.linux-x86_64-cpython-310/Hardpwl.cpython-310-x86_64-linux-gnu.so")
# __all__ = ["build_act"]

    
class Quanhswish(nn.Module):
    def __init__(self, bit=16, quan_a='lsq') -> None:
        super(Quanhswish, self).__init__()
        self.bit = bit
        # self.hswish = nn.Hardswish()
        self.pwl_hswish = hardpwl(pwl_type='hswish')
        self.lsq_a = LsqQuantizer4input(
                        bit=bit,
                        all_positive=False,
                        per_channel=False,
                    ) if quan_a == 'lsq' else PACT(num_bits=bit)
    def forward(self, input: torch.Tensor) -> torch.Tensor:
        # x_quan = input
        x_quan, scale_x = self.lsq_a(input)
        # act = torch.ops.ac.Hardpwl(x_quan, self.slops, self.intercepts, self.changepoints)
        self.pwl_hswish.scale = scale_x.detach()
        act = self.pwl_hswish(x_quan / scale_x)
        return act * scale_x  
    
class hardware_hswish(nn.Module):
    def __init__(self) -> None:
        super(hardware_hswish, self).__init__()
        # self.hswish = HardSwish8s.apply
        self.slops = torch.Tensor([0.0, -0.071929931640625, -0.070343017578125, -0.09613037109375, -0.030548095703125, 0.268951416015625, 0.622467041015625, 0.83966064453125, 0.9906005859375, 1.070465087890625, 1.0975341796875, 1.0947265625, 1.079376220703125, 1.061309814453125, 1.071929931640625, 1.0]) 
        self.intercepts = torch.Tensor([0.0, -0.359710693359375, -0.353271484375, -0.4306640625, -0.299468994140625, 0.0, 0.0, -0.108612060546875, -0.259552001953125, -0.37933349609375, -0.433441162109375, -0.426483154296875, -0.380401611328125, -0.317138671875, -0.359710693359375, 0.0])
        # self.changepoints = [-5, -4, -3, -2, -1, 0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5]
    def forward(self, input: torch.Tensor) -> torch.Tensor:
        # act = self.hswish(input)
        act = torch.ops.ac.Hardpwl(input, self.slops, self.intercepts)
        return act  
       
# register activation function here
REGISTERED_ACT_DICT: Dict[str, Type] = {
    "relu": nn.ReLU,
    "relu6": nn.ReLU6,
    "HardSwish8b8s": hardware_hswish(), 
    "quanhswish": Quanhswish(),
    # "hswish": Hardswish6(), 
    "hswish": nn.Hardswish,
}



def build_act(name: str, **kwargs) -> Optional[nn.Module]:
    if name in REGISTERED_ACT_DICT:
        act_cls = REGISTERED_ACT_DICT[name]
        args = build_kwargs_from_config(kwargs, act_cls)
        if name == "HardSwish8b8s" or name=="quanhswish":# or name=="hswish":
            return act_cls
        else:
            return act_cls(**args)
    else:
        return None
